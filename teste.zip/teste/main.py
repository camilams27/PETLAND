import os
from flask import Flask, request, jsonify, send_from_directory
import tensorflow as tf
import pickle

DIRETORIO = os.getcwd() + '/output'

dataset_dir = os.path.join(os.getcwd(), 'cats_and_dogs_filtered')

dataset_train_dir = os.path.join(dataset_dir, 'train')

dataset_validation_dir = os.path.join(dataset_dir, 'validation')

image_width = 160
image_height = 160
image_color_channel = 3
image_color_channel_size = 255
image_size = (image_width, image_height)
image_shape = image_size + (image_color_channel,)

#quantidade de features que será trazido do dataset
batch_size = 32
#quantidade de vezes que passará do dataset inteiro
epochs = 20
#taxa de aprendizagem
learning_rate = 0.0001

#saída 0,1
class_names = ['cat', 'dog']


api = Flask(__name__)


@api.route("/arquivos", methods=["GET"])
def lista_arquivos():
    arquivos = []

    for nome_do_arquivo in os.listdir(DIRETORIO):
        endereco_do_arquivo = os.path.join(DIRETORIO, nome_do_arquivo)

        if(os.path.isfile(endereco_do_arquivo)):
            arquivos.append(nome_do_arquivo)

    return jsonify(arquivos)


@api.route("/arquivos/<nome_do_arquivo>",  methods=["GET"])
def get_arquivo(nome_do_arquivo):
    return send_from_directory(DIRETORIO, nome_do_arquivo, as_attachment=True)


@api.route("/arquivos", methods=["POST"])
def post_arquivo():
    arquivo = request.files.get("meuArquivo")

    nome_do_arquivo = arquivo.filename
    arquivo.save(os.path.join(DIRETORIO, nome_do_arquivo))
    filename = 'modelo_final.pkl'
    endereco = os.path.join(os.getcwd(), filename)
    if (os.path.isfile(os.path.join(os.getcwd(), filename))):
        with open(filename, 'rb') as file:
            print(file)
            model = pickle.load(file)
    else:
        model = None
    if (model is None):
        dataset_train = tf.keras.preprocessing.image_dataset_from_directory(
            dataset_train_dir,
            image_size = image_size,
            batch_size = batch_size,
            shuffle = True
        )

        #validacao
        dataset_validation = tf.keras.preprocessing.image_dataset_from_directory(
            dataset_validation_dir,
            image_size = (image_width, image_height),
            batch_size = batch_size,
            shuffle = True
        )

        print(dataset_validation)

        dataset_validation_cardinality = tf.data.experimental.cardinality(dataset_validation)
        dataset_validation_batches = dataset_validation_cardinality // 5

        #dataset de teste
        dataset_test = dataset_validation.take(dataset_validation_batches)
        dataset_validation = dataset_validation.skip(dataset_validation_batches)

        print('Validação Dataset Cardinalidade: %d' % tf.data.experimental.cardinality(dataset_validation))
        print('Teste Dataset Cardinalidade: %d' % tf.data.experimental.cardinality(dataset_test))

        autotune = tf.data.AUTOTUNE

        dataset_train = dataset_train.prefetch(buffer_size = autotune)
        dataset_validation = dataset_validation.prefetch(buffer_size = autotune)
        dataset_test = dataset_validation.prefetch(buffer_size = autotune)

        #diminui o overfiting, realiza algumas operacoes nas features como rotacao, zoom e etc
        data_augmentation = tf.keras.models.Sequential([
            tf.keras.layers.experimental.preprocessing.RandomFlip('horizontal'),
            tf.keras.layers.experimental.preprocessing.RandomRotation(0.2),
            tf.keras.layers.experimental.preprocessing.RandomZoom(0.2)
        ])

        model_transfer_learning = tf.keras.applications.MobileNetV2(
            input_shape = image_shape, 
            include_top = False, 
            weights = 'imagenet')
        model_transfer_learning.trainable = False

        model_transfer_learning.summary()

        #criando rede neural
        #1- normalização dos valores
        model = tf.keras.models.Sequential([
        tf.keras.layers.experimental.preprocessing.Rescaling(
            1. / (image_color_channel_size / 2),
            offset = -1,
            input_shape = image_shape
        ),
        data_augmentation,
        model_transfer_learning,
        tf.keras.layers.GlobalAveragePooling2D(),
        tf.keras.layers.Dropout(0.2),
        tf.keras.layers.Dense(1, activation = 'sigmoid'),
        ])

        #ajustando os melhores parametros para o menor erro possivel
        model.compile(
            optimizer = tf.keras.optimizers.Adam(learning_rate = learning_rate),
            loss = tf.keras.losses.BinaryCrossentropy(),
            metrics = ['accuracy']
        )

        #resumo do modelo: quantidade de parametros, camadas
        model.summary()

        #treinamento da rede neural
        history = model.fit(
            dataset_train,
            validation_data = dataset_validation,
            epochs = epochs
        )

        model.save('path/to/model')
        filename = 'modelo_final.pkl'
        with open(filename, 'wb') as file:  
            pickle.dump(model, file)
        model = tf.keras.models.load_model('path/to/model')

        """Acurácia: todas que acertamos, como positivo e negativo."""

        dataset_test_loss, dataset_test_accuracy = model.evaluate(dataset_test)

        print(f'Dataset Teste Loss:     {dataset_test_loss*100:.2f} %')
        print(f'Dataset Teste Acuracia: {dataset_test_accuracy*100:.2f} %')


    image_file = os.path.join(DIRETORIO, nome_do_arquivo)
    image = tf.keras.preprocessing.image.load_img(image_file, target_size = image_size)
    image = tf.keras.preprocessing.image.img_to_array(image)
    image = tf.expand_dims(image, 0)

    prediction = model.predict(image)[0][0]
    print('Predicao: {0} | {1}'.format(prediction, ('cat' if prediction < 0.5 else 'dog')))

    return '', 201


if __name__ == "__main__":
    api.run(debug=True, port=8000)